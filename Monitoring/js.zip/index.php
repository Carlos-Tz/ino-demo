<?php
ob_start();
require_once '../../core/access_private.php';
require_once 'model.php';
require_once 'controller.php';
ob_end_clean();
